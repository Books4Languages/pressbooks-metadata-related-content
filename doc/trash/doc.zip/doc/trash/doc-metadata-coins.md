# Coins metadata

![Coins metadata](images/specific_metadata_coins.png)


Coins have just one checkbox (for Site level or Home page activation) but Educational have two checkboxes. One for Site level and the second one for Post level

# Coins

Is a method to embed bibliographic metadata on the homepage by going to its tab checking the checkbox and clicking Save Changes. As before, all metadata related to our homepage can be edited under the Tools tab by selecting Site Metadata (or Book info for PressBooks users).

![Coins vocabulary](images/vocabularies_coins.png)

---

[Readme](/Readme.md)
