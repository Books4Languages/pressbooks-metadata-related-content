# Screenshots

### 0.2

You can leave empty fields as shown below

![Resources in dashboard](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/resources_fields.JPG)


With the shortcodes you can put the information in the place that you want. Two examples are shown in the following image. One will display the information of all the fields and another will show only the one of the field videos.

![Resources in chaprter body dashboard](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/Chapter_content_shortcode.JPG)

In the frontend two tables are created because we have used it twice.

![Resources in frontend in chapter body](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/shortcode_frontend.JPG)

Resources in the frontend in footer.

![Resources in frontend in footer](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/resources_footer.JPG)

In Related Books we can also leave empty fields. The field Link of book based serves to show Link based in frontend.

![Related Books dashboard](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/related_books_dashboard.JPG)

Related books in the frontend in footer.

![Related Books frontend footer](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/related_books_footer.JPG)

This is the field of pressbooks-metadata-isced.

![Languages field](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/field_languages.JPG)

Link Based in frontend in footer.

![Link Based Frontend](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/Link_based_footer.JPG)

Setting Menu with tabs

![Setting Tabs](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/tabs.JPG)
### 0.1
![Resources in dashboard-1](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/Dashboard.JPG)
![Resources in frontend-1](https://github.com/Books4Languages/pressbooks-metadata-related_content/blob/master/pressbooks-related-content/screenshots/Frontend.JPG)
